package com.kh.great.domain.common.file;

public enum AttachCode {
  P0101, //상품관리-상품설명파일
  P0102, //상품관리-이미지파일
  B0101, //자유게시판
  B0102, //Q&A
  N0101, //공지사항
  M0101, //회원 프로필 이미지
}